﻿var indexvalue = 1;
show(indexvalue);
function go(e) {
    show(indexvalue += e);
}
function show(e) {
    var i;
    let p = document.querySelectorAll('.div2')
    if (e > p.length) {
        indexvalue = 1;
    }
    if (e < 1) {
        indexvalue = p.length;
    }
    for (i = 0; i < p.length; i++) {
        p[i].style.display = 'none';
    }
    p[indexvalue - 1].style.display = 'block';
}

function about() {
    document.getElementById('container').innerHTML = ('<link href="StyleSheet1.css" rel="stylesheet" /><h2>About Us</h2><div id="j"><div>Beltone Holding is a leading financial services provider with a multi-decade track record of success in the MENA region. The Company offers a comprehensive and growing set of financial solutions such as brokerage, investment banking, asset management, equity research, in addition to end-to-end non-banking financial institutions (NBFIs) including private equity & direct investments, leasing, factoring, consumer finance, venture capital, mortgage finance and microfinance.The Company is driven by a vision to redefine the financial ecosystem in the region by capitalizing on global expertise, knowledge, and disruptive, value - accretive solutions that unlock limitless opportunities for clients, to drive market value and impactful results.The company is listed on the Egyptian Stock Exchange under the following ticker symbol: BTFH.CA</div><img src = "who.png" /></div> ');
}
function press() {
    document.getElementById('container').innerHTML = ('<link href="StyleSheet1.css" rel="stylesheet" /><h2>Press Releases</h2><img src = "press.png" />');
}
function careers() {
    document.getElementById('container').innerHTML = ('<link href="StyleSheet1.css" rel="stylesheet" /><body><div id="bj"><h2>careers</h2><table><tr><th><input type="search" placeholder="job title,skills" /></th><th><select><option>city,state,country</option><option>Cairo,Egypt</option><option>London,England</option><option>New York,USA</option></th><th><button type="submit">Search</button></th></tr></table><div></body>');
}
function contact() {
    document.getElementById('container').innerHTML = (`<link href="StyleSheet1.css" rel="stylesheet"/><body><h2>Contact Us</h2><div id="ij"><input type="text" placeholder="Name" class="pj" style="width:300px;position: relative;height: 50px;background-color: aliceblue;margin: 15px; border-radius:20px;"/><br/><input type="text" placeholder="Email" class="pj" style="width: 300px;height: 50px;margin: 15px;background-color: aliceblue;border-radius:20px; "/><br/><input type="text" placeholder="Message" id="pj" style="width: 300px;height: 450px;background-color:gainsboro;margin: 15px;border-radius:20px; "/><br/>
    <input type="button" value="Send" style="width:300px;position: relative;height: 50px;background-color: aliceblue;margin: 15px; border-radius:20px;"/></div>
    <div id="cj">Investors Relation:<a href="#" style="color:deepskyblue;">IR @beltoneholding.com</a><br/>Complaints:<a href="#" style="color:deepskyblue;">Complaints @beltoneholding.com</a><br/>Public Relation:<a href="#" style="color:deepskyblue;">PR @beltoneholding.com</a><br/>Careers:<a href="#" style="color:deepskyblue;">careers @beltoneholding.com</a></body>`);
}
function home() {
    document.getElementById('container').innerHTML = (`<div id="container">
        <div class="frame">
        <div class="item">
                <img src="Screenshot 2024-07-25 121014.png" />
                <img src="Screenshot 2024-07-25 121058.png" />
                <img src="Screenshot 2024-07-25 121121.png" />
            </div>
        </div>
        <h2>HIGHLIGHTS</h2>
        <div class="nour">
            <div class="div1">
                <p>19 <br />Subsidaries</p>
            </div>
            <div class="div1">
                <p>
                    16<br />
                    Licenses
                </p>
            </div>

            <div class="div1">
                <p style="padding-bottom:20px;padding-top:80px;">
                    2300+ Employees
                </p>
            </div>

            <div class="div1">
                <p>
                    20+ Years Track Record
                </p>
            </div>
        </div>
        <h2>AWARDS</h2>
        <h5>In 2023, Beltone Asset Management received several prestigious awards, recognizing its outstanding performance and leadership in the financial sector:</h5>
        <div class="container">
            <box-icon name='left-arrow' id="il" onclick="go(-1)"></box-icon>
            <div class="omar">

                <div class="div2">
                    <p>Fastest Growing Asset Manager</p>
                </div>
                <div class="div2">
                    <p>Equities Manager of the Year</p>
                </div>
                <div class="div2">
                    <p>Best Asset Manager </p>
                </div>
                <div class="div2">
                    <p>Best Equity Fund Management Company</p>
                </div>
                <div class="div2">
                    <p>Fastest Growing Asset Management Firm</p>
                </div>
                <div class="div2">
                    <p>The Next 100 Global Awards 2023 B-Secure</p>
                </div>
                <div class="div2">
                    <p>Most Innovative New Fixed-Income Fund – B-Secure</p>
                </div>
                <div class="div2">
                    <p>Best Fund Management Company</p>
                </div>

            </div>
            <box-icon name='right-arrow' id="ir" onclick="go(1)"></box-icon>
        </div>
        <h2>SHARE PRICE</h2>
        <div id="price">
            <h4>Last Stock Price 3.130 EGP</h4>
            <h4>Last Change 0.00 %</h4>
            <h4> Volume 63,589,768</h4>
        </div>
        <img src="Screenshot 2024-07-25 071720.png" id="o" /><br />
    </div>`)
}